<?php defined( 'WPINC' ) || exit ; ?>
<?php

\LiteSpeed\ESI::get_instance()->load_esi_block() ;


