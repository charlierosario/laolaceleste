<?php
namespace LiteSpeed;
defined( 'WPINC' ) || exit;

require LSCWP_DIR . 'tpl/cache/settings_inc.browser.tpl.php';
